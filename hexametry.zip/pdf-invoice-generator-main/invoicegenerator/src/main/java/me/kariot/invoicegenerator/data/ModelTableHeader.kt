package me.kariot.invoicegenerator.data

class ModelTableHeader(
    val firstColoumn : String = "C1",
    val secondColoumn : String = "C2",
    val thirdColoumn : String = "C3",
    val fourthColoumn : String = "C4",
    val fifthColoumn : String = "C5",

)