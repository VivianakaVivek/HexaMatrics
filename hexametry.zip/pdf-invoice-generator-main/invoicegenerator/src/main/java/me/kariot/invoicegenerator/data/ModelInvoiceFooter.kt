package me.kariot.invoicegenerator.data

data class ModelInvoiceFooter(
    val message : String = "THANK YOU FOR YOUR BUSINESS"
)