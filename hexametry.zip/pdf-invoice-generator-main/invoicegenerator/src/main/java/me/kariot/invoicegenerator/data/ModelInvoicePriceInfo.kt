package me.kariot.invoicegenerator.data

data class ModelInvoicePriceInfo(
    val subTotal :String = "",
    val taxTotal : String = "",
    val invoiceTotal : String = ""
)