package me.kariot.invoicegenerator.data

data class ModelInvoiceItem(
    val firstItem: String,
    val firstItemDescription: String,
    val secondsItem: String,
    val thirdItem : String,
    val fourthItem: String,
    val fifthItem: String
)